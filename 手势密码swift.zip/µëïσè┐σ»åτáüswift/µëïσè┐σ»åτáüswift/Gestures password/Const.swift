//
//  Const.swift
//  手势密码
//
//  Created by haohao on 16/7/7.
//  Copyright © 2016年 haohao. All rights reserved.
//

import UIKit

//这样就是在建立宏

let kIOS8 = Double(UIDevice.currentDevice().systemVersion) >= 8.0 ? 1 : 0

let kScreenHeight = UIScreen.mainScreen().bounds.size.height
let kScreenWidth = UIScreen.mainScreen().bounds.size.width
